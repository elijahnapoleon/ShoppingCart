﻿using Microsoft.VisualBasic.FileIO;
using ShoppingCartLibrary.Models;
using System.Diagnostics;

Dictionary<Item, int>? inventory = new Dictionary<Item, int>();
Dictionary<Item, int>? cart = new Dictionary<Item, int>();
bool checkout = false;
int choice = 0;
int choice2 = 0;

while (!checkout)
{
    do
    {
        Console.WriteLine("1) Inventory Management");
        Console.WriteLine("2) Shop");

        int.TryParse(Console.ReadLine(), out choice);

        switch (choice)
        {
            case 1:
                
                do
                {
                    Console.WriteLine("1) Create Item");
                    Console.WriteLine("2) Read Item");
                    Console.WriteLine("3) Update Item");
                    Console.WriteLine("4) Delete Item");
                    Console.WriteLine("5) Back");

                    int.TryParse (Console.ReadLine(), out choice2);

                    switch(choice2)
                    {
                        case 1:
                            Item? t1 = new Item();

                            Console.WriteLine("Enter name of new item");
                            t1.Name = Console.ReadLine();
                            Console.WriteLine("Enter description of new item");
                            t1.Description = Console.ReadLine();
                            Console.WriteLine("Enter price of new item");
                            decimal.TryParse(Console.ReadLine(), out decimal price);
                            t1.Price = price;
                            Console.WriteLine("Enter Id of new item (Id has to be a positive number)");
                            int.TryParse(Console.ReadLine(), out int id);
                            t1.Id = id;
                            Console.WriteLine("Enter amount of new item");
                            int.TryParse(Console.ReadLine(), out int count);
                            if(count < 0) { Console.WriteLine("Invalid item"); break; }

                            if(t1.IsValid())
                            {
                                bool flag = false;
                                foreach(KeyValuePair<Item,int> kvp in inventory)
                                {
                                    if(kvp.Key.Id == t1.Id)
                                    {
                                        Console.WriteLine("Item with that ID already exists");
                                        flag = true;
                                        break;
                                    }
                                }
                                if(!flag)
                                { 
                                    inventory.TryAdd(t1,count);
                                }
                                
                            }
                            else { Console.WriteLine("Invalid Item"); }
                            t1 = null;
                            break;

                        case 2:
                            foreach(KeyValuePair<Item,int> kvp in inventory)
                            {
                                Console.WriteLine(kvp.Key);
                                Console.WriteLine($"{kvp.Value} in stock\n");
                            }

                            break;

                        case 3:
                            Console.WriteLine("Enter ID of item you wish to update");
                            int selection = -1;
                            int.TryParse(Console.ReadLine(), out selection);
                            foreach(KeyValuePair<Item,int> kvp in inventory)
                            {
                                if(kvp.Key.Id == selection)
                                {
                                    Console.WriteLine(kvp.Key);
                                    Console.WriteLine($"{kvp.Value} in stock\n");

                                    Item? temp = new Item();

                                    Console.WriteLine("Enter new name of item");
                                    temp.Name = Console.ReadLine();
                                    Console.WriteLine("Enter new description of item");
                                    temp.Description = Console.ReadLine();
                                    Console.WriteLine("Enter new price of item");
                                    decimal.TryParse(Console.ReadLine(), out decimal p);
                                    temp.Price = p;
                                    Console.WriteLine("Enter new Id of item (Id has to be a positive number)");
                                    int.TryParse(Console.ReadLine(), out int ide);
                                    temp.Id = ide;
                                    Console.WriteLine("Enter new amount of item");
                                    int.TryParse(Console.ReadLine(), out int amount);
                                    if (amount < 0) { Console.WriteLine("Error"); break; }

                                    if (temp.IsValid())
                                    {
                                        bool flag = false;
                                        foreach (KeyValuePair<Item, int> kvp2 in inventory)
                                        {
                                            if(kvp.Key.Id == temp.Id)
                                            {
                                                inventory.Remove(kvp.Key);
                                                inventory.TryAdd(temp, amount);
                                                break;
                                            }
                                            else if (kvp2.Key.Id == temp.Id)
                                            {
                                                Console.WriteLine("Item with that ID already exists");
                                                flag = true;
                                                break;
                                            }
                                        }
                                        if (!flag)
                                        {
                                            inventory.Remove(kvp.Key);
                                            inventory.TryAdd(temp, amount);
                                        }

                                    }
                                    else { Console.WriteLine("Error"); }
                                    temp = null;
                                    break;
                                }
                            }

                            break;

                        case 4:
                            Console.WriteLine("Enter Id of item you wish to remove");
                            int.TryParse(Console.ReadLine(), out int rId);
                            foreach(KeyValuePair<Item, int> rkvp in inventory)
                            {

                                if(rkvp.Key.Id == rId)
                                {
                                    inventory.Remove(rkvp.Key);
                                    break;
                                }
                            }
                            break;

                        case 5:
                            break;

                        default:
                            break;

                    }
                } while (choice2 != 5);
                break;

            case 2:

                do
                {
                    Console.WriteLine("Inventory\n");
                    foreach(KeyValuePair<Item,int> ckvp in inventory)
                    {
                        Console.WriteLine(ckvp.Key);
                        Console.WriteLine($"{ckvp.Value} in stock\n");
                    }
                    
                    Console.WriteLine("1) Add item to cart");
                    Console.WriteLine("2) Remove item from cart");
                    Console.WriteLine("3) Checkout");
                    int.TryParse(Console.ReadLine(), out choice2);
                    switch (choice2)
                    {
                        case 1:
                            Console.WriteLine("Enter Id of item of you wish to add to your cart");
                            int.TryParse(Console.ReadLine(), out int cId);
                            foreach (var pair in inventory)
                            {
                                if (pair.Key.Id == cId)
                                {
                                    int cAmount = 0;
                                    do
                                    {
                                        Console.WriteLine($"How many");
                                        int.TryParse(Console.ReadLine(), out cAmount);

                                        if (cAmount <= pair.Value)
                                        {
                                            cart.TryAdd(pair.Key, cAmount);
                                            inventory[pair.Key] -= cAmount;
                                            break;
                                        }

                                    } while (cAmount > pair.Value || cAmount < 1);


                                }
                            }
                            break;
                        case 2:
                            Console.WriteLine("Cart\n");
                            foreach (var pair in cart)
                            {
                                Console.WriteLine(pair.Key);
                                Console.WriteLine($"{pair.Value} in cart");
                            }

                            Console.WriteLine("Select an item to remove");
                            int.TryParse(Console.ReadLine(), out int remInt);
                            foreach (var pair in cart)
                            {
                                if (remInt == pair.Key.Id)
                                {
                                    inventory[pair.Key] += pair.Value;
                                    cart.Remove(pair.Key);
                                    break;
                                }
                            }

                            break;
                        case 3:
                            Console.WriteLine("Reciept\n");
                            decimal? subtotal = 0;
                            foreach (var pair in cart)
                            {
                                for (int i = 0; i < pair.Value; i++)
                                {
                                    Console.WriteLine($"{pair.Key.Name}     {pair.Key.Price}");
                                    subtotal += pair.Key.Price;
                                }
                            }
                            Console.WriteLine("Subtotal       $" + subtotal);
                            Console.WriteLine("Tax            7%");
                            Console.WriteLine($"Total          ${Decimal.Multiply((decimal)subtotal, (decimal)1.07)}");
                            checkout = true;
                            break;
                    }

                }while (choice2 != 3);
                break;

            default:

                break;

        }
    } while (choice != 1 && choice != 2);
}


