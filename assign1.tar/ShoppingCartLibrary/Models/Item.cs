﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCartLibrary.Models
{
    public class Item
    {
        public string? Name { get; set; }
        private string? description;
        public string? Description 
        {
            get { return description; }
            set { description = value ?? string.Empty; }
        }
        private int? id;
        public int? Id 
            {
                get => id; 
                set 
            {
                if(value < 0) { id = null; } 
                else { id = value; }
            }
            }

        private decimal? price;

        public decimal? Price
        {
            get => price;
            set
            {
                if(value < 0) {  price = null; }
                else {  price = value; }
            }
        
        }

        public Item()
        {
            Description = string.Empty;
        }

        public bool IsValid()
        {
            if (Name == null) { return false; }
            else if (price == null) { return false; }
            else if (Id == null) { return false; }

            return true;

        }

        public string Display()
        {
            return ToString();
        }

        public override string ToString()
        {
            return $"Id: {Id}\nName: {Name}\nPrice: ${Price}\nDescription: {Description}";
        }

    }
}
